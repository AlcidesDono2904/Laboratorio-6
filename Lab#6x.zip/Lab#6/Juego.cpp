#include "Juego.h"


Juego::Juego(int t1, int t2) {

	tam1 = t1;
	tam2 = t2;

	mapa = new Entidad * *[tam1];

	for (int i = 0; i < tam1; i++) {

		mapa[i] = new Entidad * [tam2];

		for (int j = 0; j < tam2; j++) {
			mapa[i][j] = nullptr;
		}

	}
}
	void Juego::iniciar() {
		
		for (int i = 0; i < tam1; i++) {
			for (int j = 0; j < tam2; j++) {
				if (i == 0) {
					if (j == 0) {
						mapa[i][j] = new Caballero;
						mapa[i][j]->setX(i);
						mapa[i][j]->setY(j);
					}
					else {
						mapa[i][j] = new Enemigo(0,1);
						mapa[i][j]->setX(i);
						mapa[i][j]->setY(j);
					}
				}
				else
					if (i < 4) {
						mapa[i][j] = new Entidad(0);
						mapa[i][j]->setX(i);
						mapa[i][j]->setY(j);
					}
					else 
						if(i>=4 && i<7){
							if (i == 4 && j == 0) {
								mapa[i][j] = new Entidad(0);
								mapa[i][j]->setX(i);
								mapa[i][j]->setY(j);
							}else
							mapa[i][j] = new Entidad(1);
							mapa[i][j]->setX(i);
							mapa[i][j]->setY(j);
						}else
							if(i==7){
								if (j < 1) {
									mapa[i][j] = new Entidad(1);
									mapa[i][j]->setX(i);
									mapa[i][j]->setY(j);
								}
								if (j >= 1 && j < 7) {
									mapa[i][j] = new Entidad(3);
									mapa[i][j]->setX(i);
									mapa[i][j]->setY(j);
								}if (j == 7) {
									mapa[i][j] = new Entidad(4);
									mapa[i][j]->setX(i);
									mapa[i][j]->setY(j);
									}
							}
							else mapa[i][j] = nullptr;			

			}
		}
		
	}

	void Juego::inicializar() {

		Entidad* aux;

		for (int i = 0; i < 82; i++) {
			int q = i;
			if (i > 8 && i < 18) {
				q = i - 9;
			}if (i > 17 && i < 27) {
				q = i - 18;
			}if (i > 26 && i < 36) {
				q = i - 27;
			}if (i > 35 && i < 45) {
				q = i - 18;
			}if (i > 44 && i < 54) {
				q = i - 45;
			}if (i > 53 && i < 63) {
				q = i - 54;
			}if (i > 62 && i < 72) {
				q = i - 63;
			}if (i > 71 && i < 81) {
				q = i - 72;
			}


			std::random_device rd;
			std::mt19937 gen(rd());
			std::uniform_int_distribution<int> distribution1(0, 9);
			int random = distribution1(gen);

			aux = mapa[q][random];

			mapa[q][random] = mapa[random][q];

			mapa[random][q] = aux;

		}
	}
	Juego::~Juego() {

		for (int i = 0; i < 9; i++) {

			delete[] mapa[i];
			
		}
	delete[] mapa;
	mapa = nullptr;

	}