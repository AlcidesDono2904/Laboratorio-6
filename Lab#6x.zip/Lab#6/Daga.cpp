#include "Daga.h"

Daga::Daga(): Arma(3) {}
Daga::~Daga(){}
bool Daga::puedeAtacar(int idenemigo) {
	return idenemigo == 1;
}