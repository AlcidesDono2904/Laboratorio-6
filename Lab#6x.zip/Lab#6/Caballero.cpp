#include "Caballero.h"

Caballero::Caballero():Entidad(2), HP(100), tam(14), can(0){}

Caballero::~Caballero() {}

int Caballero::getHP() {
	return HP;
}	

void Caballero::setHP(int HP) {
	this->HP = HP;
}

void Caballero::recogerArma(Arma* nuevaArma) {
	if (can < tam) {
		inventario[can] = nuevaArma;
		can++;
	}
}

