#ifndef GARGOLA_H
#define GARGOLA_H


#include "Enemigo.h"
class Gargola :public Enemigo{
	public:
	Gargola();
	~Gargola();
};

#endif