#include "Yesca.h"

Yesca::Yesca(): Arma(2) {}
Yesca::~Yesca(){}
bool Yesca::puedeAtacar(int idenemigo) {
	return idenemigo == 3;
}