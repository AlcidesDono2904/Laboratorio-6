#include "Gargola.h"


Gargola::Gargola() : Enemigo(0,40) {}
Gargola::~Gargola() {}
