#ifndef COFRE_H
#define COFRE_H
#include "Entidad.h"
class Cofre :public Entidad{
public:
	Cofre();
};
#endif