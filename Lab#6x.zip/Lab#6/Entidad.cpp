#include "Entidad.h"


Entidad::Entidad(int id_dato) :id(id_dato), x(0), y(0) {}
Entidad::~Entidad() {}
int Entidad::getId() { return id; }
void Entidad::setId(int id_dato) { id = id_dato; }
int Entidad::getX() { return x; }
void Entidad::setX(int x_dato) { x = x_dato; }
int Entidad::getY() { return y; }
void Entidad::setY(int y_dato) { y = y_dato; }
