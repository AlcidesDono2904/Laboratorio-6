#ifndef CABALLERO_H
#define CABALLERO_H
#include <iostream>
#include "Arma.h"
class Caballero: public Entidad{
private:
	int HP;
	Arma** inventario;
	int tam;
	int can;
public:
	Caballero();
	~Caballero();
	int getHP();
	void setHP(int HP);
	void recogerArma(Arma* nuevaArma);
};

#endif
