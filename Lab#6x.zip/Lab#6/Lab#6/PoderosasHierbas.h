#ifndef PODEROSASHIERBAS_H
#define PODEROSASHIERBAS_H
#include "Entidad.h"
class PoderosasHierbas: public Entidad {
private:

public:
	PoderosasHierbas();


};



#endif
