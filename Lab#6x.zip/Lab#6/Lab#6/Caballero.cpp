#include "Caballero.h"'

Caballero::Caballero():Entidad(2), HP(100) {}