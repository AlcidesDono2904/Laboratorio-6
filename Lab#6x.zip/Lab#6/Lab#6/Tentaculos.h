#ifndef TENTACULOS_H
#define TENTACULOS_H
#include "Enemigo.h"
class Tentaculos :  public Enemigo{
	public:
	Tentaculos();
	~Tentaculos();
};
#endif
