#include "PoderosasHierbas.h"

PoderosasHierbas::PoderosasHierbas():Entidad(3) {}