#include "Tentaculos.h"

Tentaculos::Tentaculos() : Enemigo(3, 20) {}
Tentaculos::~Tentaculos() {}