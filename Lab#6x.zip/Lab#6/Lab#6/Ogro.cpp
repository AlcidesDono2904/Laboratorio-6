#include "Ogro.h"

Ogro::Ogro() : Enemigo(1, 35) {}
Ogro::~Ogro() {}
