#include "Espada.h"

Espada::Espada(): Arma(1) {}
Espada::~Espada(){}
bool Espada::puedeAtacar(int idenemigo) {
	return (idenemigo == 1 or idenemigo == 2);
}