#include "Cofre.h"
Cofre::Cofre():Entidad(4) {}