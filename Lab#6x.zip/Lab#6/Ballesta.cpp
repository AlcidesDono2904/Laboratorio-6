#include "Ballesta.h"

Ballesta::Ballesta(): Arma(0) {}
Ballesta::~Ballesta(){}
bool Ballesta::puedeAtacar(int idenemigo) {
	return idenemigo == 0;
}